﻿#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

class Product {
public:
    string name;
    int code;
    string edinitca;
    int cost;
    Product(string name, int code, string edinitca, int cost):name(name),code(code),edinitca(edinitca),cost(cost) {}
};

void saveToFile(const vector<Product> products,const string filename) {
    ofstream file(filename);
    if (file.is_open()) {
        for (const auto& product : products) {
            file << product.name <<" "<< product.code <<" "<< product.edinitca <<" "<< product.cost<<"\n";
        }
        file.close();        
    }
}
void addProduct(const string filename) {
    string name;
    int code;
    string edinitca;
    int cost;
    cout << "Enter product name: ";
    cin >> name;
    cout << "Enter product code: ";
    cin >> code;
    cout << "Enter product edinitca: ";
    cin >> edinitca;
    cout << "Enter product cost: ";
    cin >> cost;
    vector<Product> product;
    product.push_back(Product(name, code, edinitca, cost));
    saveToFile(product, filename);
}
int main(){
    string filename = "product.txt";
    bool right=false;
    int choose;
    while (right == false)
    {
        cout << "Enter number do(1-add,2-exit): ";
        cin >> choose;
        switch (choose) {
        case 1:
            addProduct(filename); break;
        case 2:
            right=true; break;
        default:cout << "error"; break;
        }
    }   
    return 0;
}


